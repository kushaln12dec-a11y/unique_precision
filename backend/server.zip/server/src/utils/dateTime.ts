const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const IST_OFFSET_MINUTES = 5 * 60 + 30;
const IST_OFFSET_MS = IST_OFFSET_MINUTES * 60 * 1000;

export const formatDbDateTime = (date = new Date()): string => {
  const day = date.getDate().toString().padStart(2, "0");
  const month = MONTHS[date.getMonth()];
  const year = date.getFullYear();
  const hours = date.getHours().toString().padStart(2, "0");
  const minutes = date.getMinutes().toString().padStart(2, "0");
  const seconds = date.getSeconds().toString().padStart(2, "0");
  return `${day} ${month} ${year} ${hours}:${minutes}:${seconds}`;
};

export const formatDateForQuery = (isoDate: string): string => {
  const date = new Date(isoDate);
  const day = date.getDate().toString().padStart(2, "0");
  const month = MONTHS[date.getMonth()];
  const year = date.getFullYear();
  return `${day} ${month} ${year}`;
};

export const parseOperatorDateTime = (value?: string): Date | null => {
  if (!value || typeof value !== "string") return null;
  const match = value.match(/^(\d{2})\/(\d{2})\/(\d{4})\s+(\d{2}):(\d{2})(?::(\d{2}))?$/);
  if (!match) return null;
  const day = Number(match[1]);
  const month = Number(match[2]);
  const year = Number(match[3]);
  const hour = Number(match[4]);
  const minute = Number(match[5]);
  const second = Number(match[6] || 0);
  const date = new Date(Date.UTC(year, month - 1, day, hour, minute, second, 0) - IST_OFFSET_MS);
  return Number.isNaN(date.getTime()) ? null : date;
};

export const formatOperatorDateTime = (date: Date): string => {
  const d = new Date(date.getTime() + IST_OFFSET_MS);
  const day = d.getUTCDate().toString().padStart(2, "0");
  const month = (d.getUTCMonth() + 1).toString().padStart(2, "0");
  const year = d.getUTCFullYear();
  const hours = d.getUTCHours().toString().padStart(2, "0");
  const minutes = d.getUTCMinutes().toString().padStart(2, "0");
  const seconds = d.getUTCSeconds().toString().padStart(2, "0");
  return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
};

export const parseDisplayDateTime = (value?: string): Date | null => {
  if (!value || typeof value !== "string") return null;
  const trimmed = value.trim();
  if (!trimmed) return null;

  // Try legacy DD/MM/YYYY HH:MM first to avoid native Date wrongly parsing it as MM/DD/YYYY
  const legacy = parseOperatorDateTime(trimmed);
  if (legacy) return legacy;

  // Try native parsing (handles ISO strings)
  const native = new Date(trimmed);
  if (!Number.isNaN(native.getTime())) return native;

  // Format: "DD MMM YYYY HH:MM" or "DD MMM YYYY HH:MMam/pm" or "DD MMM YYYY"
  const parts = trimmed.split(" ");
  if (parts.length < 3) return null;
  const dayToken = parts[0];
  const monthToken = parts[1];
  const yearToken = parts[2];
  if (!dayToken || !monthToken || !yearToken) return null;
  const day = Number(dayToken);
  const monthIndex = MONTHS.indexOf(monthToken);
  const year = Number(yearToken);
  if (!day || monthIndex === -1 || !year) return null;

  let hours = 0;
  let minutes = 0;
  if (parts.length >= 4) {
    const timeToken = parts[3];
    const timeMatch = timeToken ? timeToken.match(/^(\d{1,2}):(\d{2})(?:\:(\d{2}))?([ap]m)?$/i) : null;
    if (timeMatch) {
      const hourToken = timeMatch[1];
      const minuteToken = timeMatch[2];
      const meridiemToken = timeMatch[4];
      hours = Number(hourToken || 0);
      minutes = Number(minuteToken || 0);
      const meridiem = (meridiemToken || "").toLowerCase();
      if (meridiem === "pm" && hours < 12) hours += 12;
      if (meridiem === "am" && hours === 12) hours = 0;
    }
  }

  const date = new Date(year, monthIndex, day, hours, minutes, 0, 0);
  return Number.isNaN(date.getTime()) ? null : date;
};

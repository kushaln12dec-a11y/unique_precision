import bcrypt from "bcrypt";
import { prisma } from "../lib/prisma";
import { formatEmpId, getEmpIdSequence, normalizeEmpId } from "../utils/employeeId";

const EMP_ID_COUNTER_KEY = "empId";

const schemaStatements: string[] = [
  `CREATE EXTENSION IF NOT EXISTS "pgcrypto";`,

  `CREATE TABLE IF NOT EXISTS "User" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "email" TEXT NOT NULL UNIQUE,
    "passwordHash" TEXT NOT NULL,
    "firstName" TEXT,
    "lastName" TEXT,
    "phone" TEXT,
    "empId" TEXT UNIQUE,
    "image" TEXT,
    "role" TEXT NOT NULL DEFAULT 'OPERATOR',
    "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );`,

  `CREATE TABLE IF NOT EXISTS "Job" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "groupId" BIGINT NOT NULL,
    "customer" TEXT,
    "rate" NUMERIC(12, 2),
    "cut" NUMERIC(12, 4),
    "thickness" NUMERIC(12, 4),
    "passLevel" TEXT,
    "setting" TEXT,
    "qty" INTEGER,
    "sedm" TEXT DEFAULT 'No',
    "sedmSelectionType" TEXT,
    "sedmRangeKey" TEXT,
    "sedmStandardValue" TEXT,
    "sedmLengthType" TEXT,
    "sedmOver20Length" NUMERIC(12, 4),
    "sedmLengthValue" NUMERIC(12, 4),
    "sedmHoles" INTEGER,
    "sedmEntriesJson" TEXT,
    "operationRowsJson" TEXT,
    "material" TEXT,
    "priority" TEXT,
    "description" TEXT,
    "remark" TEXT,
    "programRefFile" TEXT,
    "cutImage" TEXT,
    "critical" BOOLEAN NOT NULL DEFAULT FALSE,
    "pipFinish" BOOLEAN NOT NULL DEFAULT FALSE,
    "totalHrs" NUMERIC(12, 2),
    "totalAmount" NUMERIC(12, 2),
    "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "createdBy" TEXT NOT NULL,
    "assignedTo" TEXT DEFAULT 'Unassigned',
    "refNumber" TEXT,
    "startTime" TEXT,
    "endTime" TEXT,
    "machineHrs" TEXT,
    "machineNumber" TEXT,
    "opsName" TEXT,
    "idleTime" TEXT,
    "idleTimeDuration" TEXT,
    "lastImage" TEXT,
    "qcDecision" TEXT NOT NULL DEFAULT 'PENDING',
    "qcReportClosed" BOOLEAN NOT NULL DEFAULT FALSE,
    "updatedBy" TEXT,
    "updatedAt" TIMESTAMPTZ,
    "createdByUserId" UUID,
    "assignedToUserId" UUID,
    CONSTRAINT "Job_createdByUserId_fkey"
      FOREIGN KEY ("createdByUserId") REFERENCES "User"("id") ON DELETE SET NULL,
    CONSTRAINT "Job_assignedToUserId_fkey"
      FOREIGN KEY ("assignedToUserId") REFERENCES "User"("id") ON DELETE SET NULL
  );`,

  `CREATE TABLE IF NOT EXISTS "JobOperatorCapture" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "jobId" UUID NOT NULL,
    "captureMode" TEXT NOT NULL,
    "fromQty" INTEGER NOT NULL,
    "toQty" INTEGER NOT NULL,
    "quantityCount" INTEGER NOT NULL,
    "startTime" TEXT,
    "endTime" TEXT,
    "machineHrs" TEXT,
    "machineNumber" TEXT,
    "opsName" TEXT,
    "idleTime" TEXT,
    "idleTimeDuration" TEXT,
    "lastImage" TEXT,
    "createdAt" TEXT,
    "createdBy" TEXT,
    CONSTRAINT "JobOperatorCapture_jobId_fkey"
      FOREIGN KEY ("jobId") REFERENCES "Job"("id") ON DELETE CASCADE
  );`,

  `CREATE TABLE IF NOT EXISTS "JobQuantityQaState" (
    "jobId" UUID NOT NULL,
    "quantityNumber" INTEGER NOT NULL,
    "status" TEXT NOT NULL,
    CONSTRAINT "JobQuantityQaState_pkey" PRIMARY KEY ("jobId", "quantityNumber"),
    CONSTRAINT "JobQuantityQaState_jobId_fkey"
      FOREIGN KEY ("jobId") REFERENCES "Job"("id") ON DELETE CASCADE
  );`,

  `CREATE TABLE IF NOT EXISTS "EmployeeLog" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "role" TEXT NOT NULL,
    "activityType" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "userId" UUID,
    "userEmail" TEXT,
    "userName" TEXT,
    "jobId" UUID,
    "jobGroupId" BIGINT,
    "refNumber" TEXT,
    "settingLabel" TEXT,
    "quantityFrom" INTEGER,
    "quantityTo" INTEGER,
    "quantityCount" INTEGER,
    "jobCustomer" TEXT,
    "jobDescription" TEXT,
    "workItemTitle" TEXT,
    "workSummary" TEXT,
    "startedAt" TIMESTAMPTZ NOT NULL,
    "endedAt" TIMESTAMPTZ,
    "durationSeconds" INTEGER,
    "metadata" JSONB,
    "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT "EmployeeLog_userId_fkey"
      FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL,
    CONSTRAINT "EmployeeLog_jobId_fkey"
      FOREIGN KEY ("jobId") REFERENCES "Job"("id") ON DELETE SET NULL
  );`,

  `CREATE TABLE IF NOT EXISTS "MasterConfig" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "key" TEXT NOT NULL UNIQUE DEFAULT 'global',
    "settingHoursPerSetting" NUMERIC(10, 2),
    "thicknessRateUpto100" NUMERIC(12, 2),
    "thicknessRateAbove100" NUMERIC(12, 2),
    "complexExtraHours" NUMERIC(10, 2),
    "pipExtraHours" NUMERIC(10, 2),
    "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );`,

  `CREATE TABLE IF NOT EXISTS "MasterConfigCustomer" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "masterConfigId" UUID NOT NULL,
    "customer" TEXT NOT NULL,
    "rate" NUMERIC(12, 2),
    "settingHours" NUMERIC(10, 2),
    "thicknessRateUpto100" NUMERIC(12, 2),
    "thicknessRateAbove100" NUMERIC(12, 2),
    CONSTRAINT "MasterConfigCustomer_masterConfigId_fkey"
      FOREIGN KEY ("masterConfigId") REFERENCES "MasterConfig"("id") ON DELETE CASCADE,
    CONSTRAINT "MasterConfigCustomer_unique" UNIQUE ("masterConfigId", "customer")
  );`,

  `CREATE TABLE IF NOT EXISTS "MasterConfigMaterial" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "masterConfigId" UUID NOT NULL,
    "value" TEXT NOT NULL,
    CONSTRAINT "MasterConfigMaterial_masterConfigId_fkey"
      FOREIGN KEY ("masterConfigId") REFERENCES "MasterConfig"("id") ON DELETE CASCADE,
    CONSTRAINT "MasterConfigMaterial_unique" UNIQUE ("masterConfigId", "value")
  );`,

  `CREATE TABLE IF NOT EXISTS "MasterConfigPassOption" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "masterConfigId" UUID NOT NULL,
    "value" TEXT NOT NULL,
    CONSTRAINT "MasterConfigPassOption_masterConfigId_fkey"
      FOREIGN KEY ("masterConfigId") REFERENCES "MasterConfig"("id") ON DELETE CASCADE,
    CONSTRAINT "MasterConfigPassOption_unique" UNIQUE ("masterConfigId", "value")
  );`,

  `CREATE TABLE IF NOT EXISTS "MasterConfigSedmElectrodeOption" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "masterConfigId" UUID NOT NULL,
    "value" TEXT NOT NULL,
    CONSTRAINT "MasterConfigSedmElectrodeOption_masterConfigId_fkey"
      FOREIGN KEY ("masterConfigId") REFERENCES "MasterConfig"("id") ON DELETE CASCADE,
    CONSTRAINT "MasterConfigSedmElectrodeOption_unique" UNIQUE ("masterConfigId", "value")
  );`,

  `CREATE TABLE IF NOT EXISTS "MasterConfigMachineOption" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "masterConfigId" UUID NOT NULL,
    "value" TEXT NOT NULL,
    CONSTRAINT "MasterConfigMachineOption_masterConfigId_fkey"
      FOREIGN KEY ("masterConfigId") REFERENCES "MasterConfig"("id") ON DELETE CASCADE,
    CONSTRAINT "MasterConfigMachineOption_unique" UNIQUE ("masterConfigId", "value")
  );`,

  `CREATE TABLE IF NOT EXISTS "MasterConfigSedmThOption" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "masterConfigId" UUID NOT NULL,
    "value" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    CONSTRAINT "MasterConfigSedmThOption_masterConfigId_fkey"
      FOREIGN KEY ("masterConfigId") REFERENCES "MasterConfig"("id") ON DELETE CASCADE,
    CONSTRAINT "MasterConfigSedmThOption_unique" UNIQUE ("masterConfigId", "value")
  );`,

  `CREATE TABLE IF NOT EXISTS "IdleTimeConfig" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "idleTimeType" TEXT NOT NULL UNIQUE,
    "durationMinutes" INTEGER NOT NULL,
    "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );`,

  `CREATE TABLE IF NOT EXISTS "Counter" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "key" TEXT NOT NULL UNIQUE,
    "seq" INTEGER NOT NULL DEFAULT 0
  );`,

  `DO $$
  BEGIN
    IF EXISTS (
      SELECT 1
      FROM information_schema.columns
      WHERE table_schema = 'public'
        AND table_name = 'Job'
        AND column_name = 'groupId'
        AND udt_name <> 'int8'
    ) THEN
      ALTER TABLE "Job"
      ALTER COLUMN "groupId" TYPE BIGINT
      USING "groupId"::BIGINT;
    END IF;
  END $$;`,

  `DO $$
  BEGIN
    IF EXISTS (
      SELECT 1
      FROM information_schema.columns
      WHERE table_schema = 'public'
        AND table_name = 'EmployeeLog'
        AND column_name = 'jobGroupId'
        AND udt_name <> 'int8'
    ) THEN
      ALTER TABLE "EmployeeLog"
      ALTER COLUMN "jobGroupId" TYPE BIGINT
      USING "jobGroupId"::BIGINT;
    END IF;
  END $$;`,

  `CREATE INDEX IF NOT EXISTS "Job_groupId_idx" ON "Job" ("groupId");`,
  `CREATE INDEX IF NOT EXISTS "Job_createdAt_idx" ON "Job" ("createdAt");`,
  `CREATE INDEX IF NOT EXISTS "Job_groupId_createdAt_desc_idx" ON "Job" ("groupId", "createdAt" DESC);`,
  `CREATE INDEX IF NOT EXISTS "Job_customer_idx" ON "Job" ("customer");`,
  `CREATE INDEX IF NOT EXISTS "Job_description_idx" ON "Job" ("description");`,
  `CREATE INDEX IF NOT EXISTS "Job_createdBy_idx" ON "Job" ("createdBy");`,
  `CREATE INDEX IF NOT EXISTS "Job_assignedTo_idx" ON "Job" ("assignedTo");`,
  `CREATE INDEX IF NOT EXISTS "Job_priority_idx" ON "Job" ("priority");`,
  `CREATE INDEX IF NOT EXISTS "Job_sedm_idx" ON "Job" ("sedm");`,
  `CREATE INDEX IF NOT EXISTS "Job_critical_idx" ON "Job" ("critical");`,
  `CREATE INDEX IF NOT EXISTS "Job_pipFinish_idx" ON "Job" ("pipFinish");`,
  `ALTER TABLE "Job" ADD COLUMN IF NOT EXISTS "remark" TEXT;`,
  `CREATE INDEX IF NOT EXISTS "JobOperatorCapture_jobId_idx" ON "JobOperatorCapture" ("jobId");`,
  `CREATE INDEX IF NOT EXISTS "JobQuantityQaState_status_idx" ON "JobQuantityQaState" ("status");`,
  `CREATE INDEX IF NOT EXISTS "EmployeeLog_role_idx" ON "EmployeeLog" ("role");`,
  `CREATE INDEX IF NOT EXISTS "EmployeeLog_activityType_idx" ON "EmployeeLog" ("activityType");`,
  `CREATE INDEX IF NOT EXISTS "EmployeeLog_status_idx" ON "EmployeeLog" ("status");`,
  `CREATE INDEX IF NOT EXISTS "EmployeeLog_userId_idx" ON "EmployeeLog" ("userId");`,
  `CREATE INDEX IF NOT EXISTS "EmployeeLog_userEmail_idx" ON "EmployeeLog" ("userEmail");`,
  `CREATE INDEX IF NOT EXISTS "EmployeeLog_userName_idx" ON "EmployeeLog" ("userName");`,
  `CREATE INDEX IF NOT EXISTS "EmployeeLog_jobGroupId_idx" ON "EmployeeLog" ("jobGroupId");`,
  `CREATE INDEX IF NOT EXISTS "EmployeeLog_jobId_idx" ON "EmployeeLog" ("jobId");`,
  `CREATE INDEX IF NOT EXISTS "EmployeeLog_refNumber_idx" ON "EmployeeLog" ("refNumber");`,
  `CREATE INDEX IF NOT EXISTS "EmployeeLog_quantityCount_idx" ON "EmployeeLog" ("quantityCount");`,
  `CREATE INDEX IF NOT EXISTS "EmployeeLog_jobCustomer_idx" ON "EmployeeLog" ("jobCustomer");`,
  `CREATE INDEX IF NOT EXISTS "EmployeeLog_workItemTitle_idx" ON "EmployeeLog" ("workItemTitle");`,
  `CREATE INDEX IF NOT EXISTS "EmployeeLog_startedAt_idx" ON "EmployeeLog" ("startedAt");`,
  `CREATE INDEX IF NOT EXISTS "EmployeeLog_durationSeconds_idx" ON "EmployeeLog" ("durationSeconds");`,
  `ALTER TABLE "MasterConfig" ADD COLUMN IF NOT EXISTS "thicknessRateUpto100" NUMERIC(12, 2);`,
  `ALTER TABLE "MasterConfig" ADD COLUMN IF NOT EXISTS "thicknessRateAbove100" NUMERIC(12, 2);`,
  `ALTER TABLE "MasterConfigCustomer" ADD COLUMN IF NOT EXISTS "settingHours" NUMERIC(10, 2);`,
  `ALTER TABLE "MasterConfigCustomer" ADD COLUMN IF NOT EXISTS "thicknessRateUpto100" NUMERIC(12, 2);`,
  `ALTER TABLE "MasterConfigCustomer" ADD COLUMN IF NOT EXISTS "thicknessRateAbove100" NUMERIC(12, 2);`,
];

export const initDB = async (): Promise<void> => {
  console.log("Initializing database schema...");

  try {
    for (const statement of schemaStatements) {
      await prisma.$executeRawUnsafe(statement);
    }
    console.log("Database schema ensured.");
  } catch (error) {
    console.error("Database schema initialization failed:", error);
    return;
  }

  try {
    const passwordHash = await bcrypt.hash("raki123", 10);
    await prisma.$executeRaw`
      INSERT INTO "User" ("email", "passwordHash", "empId", "role", "createdAt", "updatedAt")
      VALUES (${`rakis@gmail.com`}, ${passwordHash}, ${"EMP0001"}, ${"ADMIN"}, NOW(), NOW())
      ON CONFLICT ("email") DO UPDATE
      SET "empId" = COALESCE("User"."empId", EXCLUDED."empId");
    `;
    console.log("Default admin ensured.");

    const allUsers = await prisma.user.findMany({
      select: { id: true, empId: true },
      orderBy: { createdAt: "asc" },
    });
    let normalizedEmpIdsUpdated = 0;
    for (const user of allUsers) {
      const currentEmpId = String(user.empId || "").trim();
      if (!currentEmpId) continue;

      const normalizedEmpId = normalizeEmpId(currentEmpId);
      if (!normalizedEmpId || normalizedEmpId === currentEmpId) continue;

      try {
        await prisma.user.update({
          where: { id: user.id },
          data: { empId: normalizedEmpId },
        });
        normalizedEmpIdsUpdated += 1;
      } catch (normalizeError: any) {
        console.warn(`Skipped EMP ID normalization for user ${user.id}:`, normalizeError?.message || normalizeError);
      }
    }

    if (normalizedEmpIdsUpdated > 0) {
      console.log(`Normalized Employee IDs for ${normalizedEmpIdsUpdated} existing user(s).`);
    }

    const refreshedUsers = await prisma.user.findMany({
      select: { id: true, empId: true },
      orderBy: { createdAt: "asc" },
    });
    const usersMissingEmpId = refreshedUsers.filter((user) => !String(user.empId || "").trim());
    const maxExistingSequence = refreshedUsers.reduce((maxValue, user) => {
      return Math.max(maxValue, getEmpIdSequence(user.empId));
    }, 0);

    if (usersMissingEmpId.length > 0) {
      let nextSequence = maxExistingSequence;
      for (const user of usersMissingEmpId) {
        nextSequence += 1;
        await prisma.user.update({
          where: { id: user.id },
          data: { empId: formatEmpId(nextSequence) },
        });
      }
      await prisma.counter.upsert({
        where: { key: EMP_ID_COUNTER_KEY },
        update: { seq: nextSequence },
        create: { key: EMP_ID_COUNTER_KEY, seq: nextSequence },
      });
      console.log(`Assigned Employee IDs to ${usersMissingEmpId.length} existing user(s).`);
    } else {
      const counterSequence = Math.max(0, Number((await prisma.counter.findUnique({ where: { key: EMP_ID_COUNTER_KEY } }))?.seq || 0));
      const targetSequence = Math.max(counterSequence, maxExistingSequence);
      await prisma.counter.upsert({
        where: { key: EMP_ID_COUNTER_KEY },
        update: { seq: targetSequence },
        create: { key: EMP_ID_COUNTER_KEY, seq: targetSequence },
      });
    }
  } catch (error) {
    console.error("Failed to insert default admin user:", error);
  }
};

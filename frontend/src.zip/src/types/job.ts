import type { CutForm } from "../pages/Programmer/types/programmer";

export type OperatorCaptureEntry = {
  captureMode: "SINGLE" | "RANGE";
  fromQty: number;
  toQty: number;
  quantityCount: number;
  startTime: string;
  endTime: string;
  machineHrs: string;
  machineNumber: string;
  opsName: string;
  idleTime: string;
  idleTimeDuration: string;
  lastImage: string | null;
  createdAt: string;
  createdBy: string;
};

export type QuantityQaStatus = "SAVED" | "READY_FOR_QA" | "SENT_TO_QA";

export type JobEntry = CutForm & {
  id: number | string;
  groupId: string | number;
  totalHrs: number;
  totalAmount: number;
  wedmAmount: number;
  sedmAmount: number;
  createdAt: string;
  createdBy: string;
  updatedAt?: string;
  updatedBy?: string;
  assignedTo: string;
  machineNumber?: string;
  startTime?: string;
  endTime?: string;
  machineHrs?: string;
  opsName?: string | string[];
  idleTime?: string;
  idleTimeDuration?: string;
  lastImage?: string | null;
  qcDecision?: "PENDING" | "APPROVED" | "REJECTED";
  qcReportClosed?: boolean;
  operatorCaptures?: OperatorCaptureEntry[];
  quantityQaStates?: Record<string, QuantityQaStatus>;
};

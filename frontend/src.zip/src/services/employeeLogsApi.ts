import type { EmployeeLog, EmployeeLogQueryStatus } from "../types/employeeLog";
import { apiUrl } from "./apiClient";
import { syncServerTimeOffset } from "./serverTime";

export type PaginatedEmployeeLogs = {
  items: EmployeeLog[];
  total: number;
  offset: number;
  limit: number;
  hasMore: boolean;
};

const getAuthHeaders = () => {
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`,
  };
};

const fetchWithServerTime = async (input: string, init?: RequestInit) => {
  const requestStartedAtMs = Date.now();
  const response = await fetch(apiUrl(input), init);
  syncServerTimeOffset(response, {
    requestStartedAtMs,
    responseReceivedAtMs: Date.now(),
    maxRoundTripMs: 2000,
  });
  return response;
};

type GetEmployeeLogsParams = {
  role?: "PROGRAMMER" | "OPERATOR" | "QC";
  status?: EmployeeLogQueryStatus;
  activityType?: "PROGRAMMER_JOB_CREATION" | "OPERATOR_PRODUCTION" | "OPERATOR_ASSIGNMENT" | "QA_REVIEW";
  search?: string;
  machine?: string;
  jobId?: string;
  jobGroupId?: string;
  startDate?: string;
  endDate?: string;
  offset?: number;
  limit?: number;
};

const getEmployeeLogItems = (payload: any): EmployeeLog[] => {
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.items)) return payload.items;
  return [];
};

const EMPLOYEE_LOGS_DEDUPE_TTL_MS = 1200;
const employeeLogsInFlight = new Map<string, Promise<any>>();
const employeeLogsResponseCache = new Map<string, { expiresAt: number; payload: any }>();
const ACTIVE_OPERATOR_RUNS_CACHE_TTL_MS = 2000;
const ACTIVE_OPERATOR_RUNS_URL = "/api/employee-logs?role=OPERATOR&status=IN_PROGRESS&limit=250";

export const invalidateEmployeeLogsCache = (matcher?: string | RegExp) => {
  const shouldDelete = (key: string) => {
    if (!matcher) return true;
    if (typeof matcher === "string") return key.includes(matcher);
    return matcher.test(key);
  };

  Array.from(employeeLogsInFlight.keys()).forEach((key) => {
    if (shouldDelete(key)) employeeLogsInFlight.delete(key);
  });
  Array.from(employeeLogsResponseCache.keys()).forEach((key) => {
    if (shouldDelete(key)) employeeLogsResponseCache.delete(key);
  });
};

const fetchEmployeeLogsPayload = async (url: string): Promise<any> => {
  const now = Date.now();
  const cached = employeeLogsResponseCache.get(url);
  if (cached && cached.expiresAt > now) {
    return cached.payload;
  }

  const inFlight = employeeLogsInFlight.get(url);
  if (inFlight) {
    return inFlight;
  }

  const request = fetchWithServerTime(url, {
    method: "GET",
    headers: getAuthHeaders(),
  })
    .then(async (res) => {
      if (!res.ok) {
        throw new Error("Failed to fetch employee logs");
      }

      const payload = await res.json();
      employeeLogsResponseCache.set(url, {
        expiresAt: Date.now() + EMPLOYEE_LOGS_DEDUPE_TTL_MS,
        payload,
      });
      return payload;
    })
    .finally(() => {
      employeeLogsInFlight.delete(url);
    });

  employeeLogsInFlight.set(url, request);
  return request;
};

export const getEmployeeLogs = async (params: GetEmployeeLogsParams = {}): Promise<EmployeeLog[]> => {
  const query = new URLSearchParams();
  if (params.role) query.append("role", params.role);
  if (params.status) query.append("status", params.status);
  if (params.activityType) query.append("activityType", params.activityType);
  if (params.search) query.append("search", params.search);
  if (params.machine) query.append("machine", params.machine);
  if (params.jobId) query.append("jobId", params.jobId);
  if (params.jobGroupId) query.append("jobGroupId", params.jobGroupId);
  if (params.startDate) query.append("startDate", params.startDate);
  if (params.endDate) query.append("endDate", params.endDate);

  const url = query.toString() ? `/api/employee-logs?${query.toString()}` : "/api/employee-logs";
  const payload = await fetchEmployeeLogsPayload(url);
  return getEmployeeLogItems(payload);
};

export const getActiveOperatorRunLogs = async (): Promise<EmployeeLog[]> => {
  const payload = await fetchEmployeeLogsPayload(ACTIVE_OPERATOR_RUNS_URL);
  employeeLogsResponseCache.set(ACTIVE_OPERATOR_RUNS_URL, {
    expiresAt: Date.now() + ACTIVE_OPERATOR_RUNS_CACHE_TTL_MS,
    payload,
  });
  return getEmployeeLogItems(payload);
};

export const getEmployeeLogsPage = async (
  params: GetEmployeeLogsParams = {}
): Promise<PaginatedEmployeeLogs> => {
  const query = new URLSearchParams();
  if (params.role) query.append("role", params.role);
  if (params.status) query.append("status", params.status);
  if (params.activityType) query.append("activityType", params.activityType);
  if (params.search) query.append("search", params.search);
  if (params.machine) query.append("machine", params.machine);
  if (params.jobId) query.append("jobId", params.jobId);
  if (params.jobGroupId) query.append("jobGroupId", params.jobGroupId);
  if (params.startDate) query.append("startDate", params.startDate);
  if (params.endDate) query.append("endDate", params.endDate);
  if (params.offset !== undefined) query.append("offset", String(Math.max(0, params.offset)));
  if (params.limit !== undefined) query.append("limit", String(Math.max(1, params.limit)));

  const url = query.toString() ? `/api/employee-logs?${query.toString()}` : "/api/employee-logs";
  const payload = await fetchEmployeeLogsPayload(url);
  const items = getEmployeeLogItems(payload);
  return {
    items,
    total: Number(payload?.total || items.length || 0),
    offset: Number(payload?.offset || 0),
    limit: Number(payload?.limit || items.length || 0),
    hasMore: Boolean(payload?.hasMore),
  };
};

export const startProgrammerJobLog = async (payload: { refNumber?: string } = {}): Promise<EmployeeLog> => {
  const res = await fetchWithServerTime("/api/employee-logs/programmer/start", {
    method: "POST",
    headers: getAuthHeaders(),
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    throw new Error("Failed to start programmer log");
  }

  return res.json();
};

export const completeProgrammerJobLog = async (payload: {
  logId?: string;
  jobGroupId?: string;
  refNumber?: string;
  customer?: string;
  description?: string;
  settingsCount?: number;
  quantityCount?: number;
}): Promise<EmployeeLog> => {
  const res = await fetchWithServerTime("/api/employee-logs/programmer/complete", {
    method: "POST",
    headers: getAuthHeaders(),
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    throw new Error("Failed to complete programmer log");
  }

  return res.json();
};

export const rejectProgrammerJobLog = async (payload: {
  logId?: string;
}): Promise<EmployeeLog> => {
  const res = await fetchWithServerTime("/api/employee-logs/programmer/reject", {
    method: "POST",
    headers: getAuthHeaders(),
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    throw new Error("Failed to reject programmer log");
  }

  return res.json();
};

export const startOperatorProductionLog = async (payload: {
  jobId: string | number;
  jobGroupId?: string;
  refNumber?: string;
  customer?: string;
  description?: string;
  settingLabel?: string;
  fromQty?: number;
  toQty?: number;
  quantityCount?: number;
  startedAt?: string;
  machineNumber?: string;
  opsName?: string;
}): Promise<EmployeeLog> => {
  const res = await fetchWithServerTime("/api/employee-logs/operator/start", {
    method: "POST",
    headers: getAuthHeaders(),
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const errorBody = await res.json().catch(() => ({ message: "Failed to start operator production log" }));
    const err = new Error(errorBody.message || "Failed to start operator production log") as Error & { conflictJobId?: string; conflictJobGroupId?: string };
    if (errorBody.conflictJobId) err.conflictJobId = String(errorBody.conflictJobId);
    if (errorBody.conflictJobGroupId) err.conflictJobGroupId = String(errorBody.conflictJobGroupId);
    throw err;
  }

  invalidateEmployeeLogsCache(/employee-logs/);
  return res.json();
};

export const completeOperatorProductionLog = async (payload: {
  logId?: string;
  status?: "COMPLETED" | "REJECTED";
  endedAt?: string;
  machineNumber?: string;
  opsName?: string;
  machineHrs?: string;
  workedSeconds?: number;
  idleTime?: string;
  idleTimeDuration?: string;
  pauseSessions?: Array<{
    pauseStartTime: number;
    pauseEndTime: number | null;
    pauseDuration: number;
    reason: string;
    operatorName?: string;
  }>;
}): Promise<EmployeeLog> => {
  const res = await fetchWithServerTime("/api/employee-logs/operator/complete", {
    method: "POST",
    headers: getAuthHeaders(),
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const error = await res.json().catch(() => ({ message: "Failed to complete operator production log" }));
    throw new Error(error.message || "Failed to complete operator production log");
  }

  invalidateEmployeeLogsCache(/employee-logs/);
  return res.json();
};

export const createOperatorTaskSwitchLog = async (payload: {
  idleTime: string;
  remark: string;
  startedAt: string;
  endedAt: string;
  durationSeconds: number;
}): Promise<EmployeeLog> => {
  const res = await fetchWithServerTime("/api/employee-logs/operator/task-switch", {
    method: "POST",
    headers: getAuthHeaders(),
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const error = await res.json().catch(() => ({ message: "Failed to save task switch log" }));
    throw new Error(error.message || "Failed to save task switch log");
  }

  return res.json();
};

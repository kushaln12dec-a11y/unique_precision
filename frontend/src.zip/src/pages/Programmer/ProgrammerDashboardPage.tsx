import { useCallback, useMemo, useState } from "react";
import { useNavigate, Routes, Route, Navigate } from "react-router-dom";
import Sidebar from "../../components/Sidebar";
import Header from "../../components/Header";
import { getUserRoleFromToken } from "../../utils/auth";
import "../../utils/tokenDebug";
import ProgrammerPageOverlays from "./components/ProgrammerPageOverlays";
import ProgrammerJobsSection from "./components/ProgrammerJobsSection";
import ProgrammerLogsSection from "./components/ProgrammerLogsSection";
import ProgrammerFormSection from "./components/ProgrammerFormSection";

import { calculateTotals } from "./programmerUtils";
import type { JobEntry } from "../../types/job";
import { useJobHandlers } from "./hooks/useJobHandlers";
import { useTableColumns } from "./hooks/useTableColumns";
import { useProgrammerState } from "./hooks/useProgrammerState";
import { exportJobsToCSV } from "./utils/csvExport";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { useProgrammerGrid } from "./hooks/useProgrammerGrid";
import { useProgrammerLogs } from "./hooks/useProgrammerLogs";
import { useProgrammerPageController } from "./hooks/useProgrammerPageController";
import { useProgrammerReduxDispatchers } from "./hooks/useProgrammerReduxDispatchers";
import { useProgrammerNavigation } from "./hooks/useProgrammerNavigation";
import { useJobSync } from "../../hooks/useJobSync";
import "../RoleBoard.css";
import "./Programmer.css";

const ProgrammerDashboardPage = ({ forceTab, hideLayout, mode }: { forceTab?: "jobs" | "logs"; hideLayout?: boolean; mode?: "billed" | "standard" }) => {
  const navigate = useNavigate();

  const dispatch = useAppDispatch();

  const [sortField] = useState<keyof JobEntry | null>(null);
  const [sortDirection] = useState<"asc" | "desc">("asc");
  const [toast, setToast] = useState<{ message: string; variant: "success" | "error" | "info"; visible: boolean }>({
    message: "",
    variant: "success",
    visible: false,
  });
  const [savingJob, setSavingJob] = useState(false);

  const {
    filters,
    showFilterModal,
    customerFilter,
    descriptionFilter,
    createdByFilter,
    criticalFilter,
    searchFilter,
  } = useAppSelector((state) => state.filters.programmer);

  const isAdmin = getUserRoleFromToken() === "ADMIN";

  const {
    currentPathname,
    jobs,
    loadingJobs,
    loadingEditGroup,
    setJobs,
    cuts,
    setCuts,
    editingGroupId,
    refNumber,
    editGroupError,
    refreshJobs,
    handleNewJob: handleNewJobState,
    handleCancel: handleCancelState,
  } = useProgrammerState(filters, customerFilter, descriptionFilter, createdByFilter, criticalFilter, searchFilter);

  const {
    users,
    showDeleteModal,
    setShowDeleteModal,
    jobToDelete,
    setJobToDelete,
    selectedJobIds,
    setSelectedJobIds,
    showJobViewModal,
    setShowJobViewModal,
    viewingJob,
    setViewingJob,
    selectedChildRows,
    expandedGroups,
    programmerGridJobs,
    setProgrammerGridJobs,
    programmerGridRefreshKey,
    masterConfig,
    activeTab,
    logSearch,
    setLogSearch,
    logStatus,
    setLogStatus,
    logUserId,
    setLogUserId,
    activeFilterCount,
    isProgrammerListRoute,
    isProgrammerFormRoute,
    shouldRenderJobForm,
    shouldRenderEditLoadingState,
    shouldRenderEditErrorState,
    handleChildRowSelect,
    toggleGroup,
    handleDeleteClick,
    handleViewEntry,
    handleViewGroup,
    handleCloneJob,
    handleNewJob,
    handleCancel,
    refreshProgrammerGrid,
    jobsFetchPage,
    logsFetchPage,
  } = useProgrammerPageController({
    filters,
    customerFilter,
    descriptionFilter,
    createdByFilter,
    criticalFilter,
    searchFilter,
    loadingJobs,
    cutsLength: cuts.length,
    editGroupError,
    editingGroupId,
    handleNewJobState,
    handleCancelState,
    setToast,
    forceTab,
    isBilled: mode === "billed",
  });

  const refreshProgrammerDashboard = useCallback(() => {
    void refreshJobs();
    refreshProgrammerGrid();
  }, [refreshJobs, refreshProgrammerGrid]);

  useJobSync((event) => {
    refreshProgrammerDashboard();
    setToast({
      message: `${event.updatedBy || "Another user"} updated jobs. Refreshing list...`,
      variant: "info",
      visible: true,
    });
    window.setTimeout(() => setToast((prev) => ({ ...prev, visible: false })), 2500);
  }, isProgrammerListRoute && activeTab === "jobs");

  const totals = useMemo(
    () =>
      cuts.map((cut) =>
        calculateTotals(cut, {
          settingHoursPerSetting: masterConfig?.settingHoursPerSetting,
          thicknessRateUpto100: masterConfig?.thicknessRateUpto100,
          thicknessRateAbove100: masterConfig?.thicknessRateAbove100,
          complexExtraHours: masterConfig?.complexExtraHours,
          pipExtraHours: masterConfig?.pipExtraHours,
          customerConfigs: masterConfig?.customers,
        })
      ),
    [cuts, masterConfig]
  );

  const { handleSaveJob, handleDeleteJob, handleMassDelete, handleEditJob, cancelSave } = useJobHandlers({
    cuts,
    editingGroupId,
    refNumber,
    jobs,
    setJobs,
    setToast,
    setSavingJob,
    handleCancelState,
    totals,
  });

  const handleDeleteConfirm = async () => {
    if (!jobToDelete) return;
    try {
      await handleDeleteJob(jobToDelete.groupId);
      setProgrammerGridJobs((prev) => prev.filter((job) => String(job.groupId) !== jobToDelete.groupId));
      setShowDeleteModal(false);
      setJobToDelete(null);
    } catch {
      // toast handled upstream
    }
  };

  const handleMassDeleteClick = async () => {
    if (selectedJobIds.size === 0) return;
    await handleMassDelete(selectedJobIds);
    setProgrammerGridJobs((prev) => prev.filter((job) => !selectedJobIds.has(String(job.groupId))));
    setSelectedJobIds(new Set());
  };

  const columns = useTableColumns({
    isAdmin,
    handleViewGroup,
    handleViewEntry,
    handleEditJob,
    handleCloneJob: (groupId) => handleCloneJob(groupId, navigate),
    handleDeleteClick,
    toggleGroup,
  });

  const {
    filteredProgrammerTableData,
    programmerGridRows,
    programmerJobColumnDefs,
  } = useProgrammerGrid({
    programmerGridJobs,
    sortField,
    sortDirection,
    expandedGroups,
    toggleGroup,
    isAdmin,
    selectedChildRows,
    onChildRowSelect: handleChildRowSelect,
    handleEditJob,
    handleDeleteClick,
    handleViewEntry,
    selectedJobIds,
    setSelectedJobIds,
    searchFilter,
    columns,
  });

  const {
    filterProgrammerLogs,
    handleExportProgrammerLogsCsv,
    programmerLogColumnDefs,
    programmerUsers,
  } = useProgrammerLogs({ users, logSearch, logStatus, logUserId, setToast });

  const handleDownloadCSV = () => exportJobsToCSV(filteredProgrammerTableData, isAdmin);
  const dispatchers = useProgrammerReduxDispatchers(dispatch, filters);
  const { handleProgrammerNavigate, navigateToProgrammerList } = useProgrammerNavigation({
    isProgrammerFormRoute,
    navigate,
    handleCancelState,
    setSavingJob,
    cancelSave,
  });

  const shouldShowNewJobButton = mode !== "billed";

  return (
    <div className={hideLayout ? `standalone-page-wrapper ${mode === "billed" ? "billed-programmer-wrapper" : ""}`.trim() : "programmer-container"}>
      {!hideLayout && <Sidebar currentPath={currentPathname} onNavigate={handleProgrammerNavigate} />}
      <div className={`${hideLayout ? "" : "programmer-content"} ${isProgrammerFormRoute ? "programmer-content-scrollable" : ""}`}>
        {!hideLayout && <Header title="Programmer" onNavigate={handleProgrammerNavigate} />}
        <div className={`programmer-panel ${isProgrammerFormRoute ? "programmer-panel-scrollable" : ""}`}>
          <Routes>
            <Route
              index
              element={
                <>
                  {activeTab === "jobs" ? (
                    <ProgrammerJobsSection
                      savingJob={savingJob}
                      programmerGridJobs={programmerGridJobs}
                      filters={filters}
                      createdByFilter={createdByFilter}
                      criticalFilter={criticalFilter}
                      searchFilter={searchFilter}
                      showFilterModal={showFilterModal}
                      activeFilterCount={activeFilterCount}
                      users={users}
                      dispatchers={dispatchers}
                      handleDownloadCSV={handleDownloadCSV}
                      handleNewJob={shouldShowNewJobButton ? () => handleNewJob(navigate) : undefined}
                      fetchPage={jobsFetchPage}
                      rows={programmerGridRows}
                      columnDefs={programmerJobColumnDefs}
                      setProgrammerGridJobs={setProgrammerGridJobs}
                      expandedGroups={expandedGroups}
                      programmerGridRefreshKey={programmerGridRefreshKey}
                    />
                  ) : (
                    <ProgrammerLogsSection
                      logSearch={logSearch}
                      setLogSearch={setLogSearch}
                      logStatus={logStatus}
                      setLogStatus={setLogStatus}
                      logUserId={logUserId}
                      setLogUserId={setLogUserId}
                      programmerUsers={programmerUsers}
                      handleExportProgrammerLogsCsv={handleExportProgrammerLogsCsv}
                      programmerLogColumnDefs={programmerLogColumnDefs}
                      filterProgrammerLogs={filterProgrammerLogs}
                      fetchPage={logsFetchPage}
                    />
                  )}
                </>
              }
            />

            <Route
              path="newjob"
              element={
                <ProgrammerFormSection
                  shouldRenderJobForm={true}
                  loadingEditGroup={loadingEditGroup}
                  cuts={cuts}
                  setCuts={setCuts}
                  handleSaveJob={handleSaveJob}
                  handleCancel={() => handleCancel(navigate)}
                  totals={totals}
                  isAdmin={isAdmin}
                  savingJob={savingJob}
                  refNumber={refNumber}
                  masterConfig={masterConfig}
                  editingGroupId={editingGroupId}
                  shouldRenderEditLoadingState={false}
                  shouldRenderEditErrorState={false}
                  editGroupError={null}
                  onBack={navigateToProgrammerList}
                />
              }
            />

            <Route
              path="edit/:groupId"
              element={
                <ProgrammerFormSection
                  shouldRenderJobForm={shouldRenderJobForm}
                  loadingEditGroup={loadingEditGroup}
                  cuts={cuts}
                  setCuts={setCuts}
                  handleSaveJob={handleSaveJob}
                  handleCancel={() => handleCancel(navigate)}
                  totals={totals}
                  isAdmin={isAdmin}
                  savingJob={savingJob}
                  refNumber={refNumber}
                  masterConfig={masterConfig}
                  editingGroupId={editingGroupId}
                  shouldRenderEditLoadingState={shouldRenderEditLoadingState}
                  shouldRenderEditErrorState={shouldRenderEditErrorState}
                  editGroupError={editGroupError}
                  onBack={navigateToProgrammerList}
                />
              }
            />

            <Route
              path="clone/:groupId"
              element={
                <ProgrammerFormSection
                  shouldRenderJobForm={true}
                  loadingEditGroup={loadingEditGroup}
                  cuts={cuts}
                  setCuts={setCuts}
                  handleSaveJob={handleSaveJob}
                  handleCancel={() => handleCancel(navigate)}
                  totals={totals}
                  isAdmin={isAdmin}
                  savingJob={savingJob}
                  refNumber={refNumber}
                  masterConfig={masterConfig}
                  editingGroupId={null}
                  shouldRenderEditLoadingState={false}
                  shouldRenderEditErrorState={false}
                  editGroupError={null}
                  onBack={navigateToProgrammerList}
                />
              }
            />

            <Route path="*" element={<Navigate to="/programmer" replace={false} />} />
          </Routes>
        </div>
      </div>

      <ProgrammerPageOverlays
        toast={toast}
        setToast={setToast}
        showDeleteModal={showDeleteModal}
        setShowDeleteModal={setShowDeleteModal}
        jobToDelete={jobToDelete}
        setJobToDelete={setJobToDelete}
        handleDeleteConfirm={handleDeleteConfirm}
        showJobViewModal={showJobViewModal}
        viewingJob={viewingJob}
        setShowJobViewModal={setShowJobViewModal}
        setViewingJob={setViewingJob}
        getUserRole={getUserRoleFromToken}
        showMassDelete={isProgrammerListRoute && activeTab === "jobs"}
        selectedCount={selectedJobIds.size}
        onMassDelete={handleMassDeleteClick}
        onClearSelection={() => setSelectedJobIds(new Set())}
      />
    </div>
  );
};

export default ProgrammerDashboardPage;

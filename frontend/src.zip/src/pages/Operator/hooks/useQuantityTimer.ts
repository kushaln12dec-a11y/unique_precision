import { useEffect, useMemo, useState } from "react";
import { getServerNowMs } from "../../../services/serverTime";
import { parseISTDateTimeToMs } from "../../../utils/dateTime";

const formatHMS = (seconds: number): string => {
  const safe = Math.max(0, Math.floor(seconds));
  const h = Math.floor(safe / 3600);
  const m = Math.floor((safe % 3600) / 60);
  const s = safe % 60;
  return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
};

const parseDateTime = (value?: string): number | null => {
  return parseISTDateTimeToMs(value);
};

export const useQuantityTimer = (
  startTime?: string,
  endTime?: string,
  isPaused?: boolean,
  pauseStartTime?: number | null,
  currentPauseReason?: string,
  totalPauseTime?: number,
  pauseTimeOffsetSeconds?: number,
  pausedElapsedTime?: number,
  workedDurationSeconds?: number,
  startTimeEpochMs?: number | null,
  endTimeEpochMs?: number | null,
  requiredDurationSeconds?: number
) => {
  const [now, setNow] = useState<number>(getServerNowMs());

  const startMs = useMemo(
    () => (startTimeEpochMs && Number.isFinite(startTimeEpochMs) ? Number(startTimeEpochMs) : parseDateTime(startTime)),
    [startTimeEpochMs, startTime]
  );
  const endMs = useMemo(
    () => (endTimeEpochMs && Number.isFinite(endTimeEpochMs) ? Number(endTimeEpochMs) : parseDateTime(endTime)),
    [endTimeEpochMs, endTime]
  );

  const hasStarted = Boolean(startMs);
  const hasEnded = Boolean(endMs);
  const running = hasStarted && !hasEnded;

  useEffect(() => {
    if (!running) return;
    const id = window.setInterval(() => setNow(getServerNowMs()), 1000);
    return () => window.clearInterval(id);
  }, [running]);

  const computedElapsedSeconds = useMemo(() => {
    const carriedWorkedSeconds = Math.max(0, Math.floor(Number(workedDurationSeconds || 0)));
    const pauseOffsetSeconds = Math.max(0, Math.floor(Number(pauseTimeOffsetSeconds || 0)));
    const segmentPauseSeconds = Math.max(0, Math.floor(Number(totalPauseTime || 0)) - pauseOffsetSeconds);
    if (!startMs) return 0;
    if (endMs) {
      const base = Math.max(0, Math.floor((endMs - startMs) / 1000));
      const closedSegmentSeconds = Math.max(0, base - segmentPauseSeconds);
      const hasLocalEndEpoch = endTimeEpochMs && Number.isFinite(Number(endTimeEpochMs));
      if (hasLocalEndEpoch) {
        return Math.max(0, carriedWorkedSeconds + closedSegmentSeconds);
      }
      return Math.max(0, carriedWorkedSeconds || closedSegmentSeconds);
    }

    if (isPaused) {
      return Math.max(0, Math.floor(pausedElapsedTime || carriedWorkedSeconds));
    }

    const shouldTrackLivePause = currentPauseReason !== "Shift Over";
    const runningPauseSeconds =
      pauseStartTime && isPaused && shouldTrackLivePause ? Math.max(0, Math.floor((now - pauseStartTime) / 1000)) : 0;
    const raw = Math.max(0, Math.floor((now - startMs) / 1000));
    return Math.max(0, carriedWorkedSeconds + raw - Math.floor(segmentPauseSeconds + runningPauseSeconds));
  }, [startMs, endMs, isPaused, pausedElapsedTime, totalPauseTime, pauseTimeOffsetSeconds, pauseStartTime, currentPauseReason, now, workedDurationSeconds, endTimeEpochMs]);

  const computedPauseSeconds = useMemo(() => {
    const base = Math.max(0, Math.floor(totalPauseTime || 0));
    if (isPaused && pauseStartTime) {
      return base + Math.max(0, Math.floor((now - pauseStartTime) / 1000));
    }
    return base;
  }, [totalPauseTime, isPaused, pauseStartTime, currentPauseReason, now]);

  const computedRemainingSeconds = useMemo(() => {
    const required = Math.max(0, Math.floor(Number(requiredDurationSeconds || 0)));
    if (required <= 0) return 0;
    return Math.max(0, required - computedElapsedSeconds);
  }, [requiredDurationSeconds, computedElapsedSeconds]);

  const computedOvertimeSeconds = useMemo(() => {
    const required = Math.max(0, Math.floor(Number(requiredDurationSeconds || 0)));
    if (required <= 0) return 0;
    return Math.max(0, computedElapsedSeconds - required);
  }, [requiredDurationSeconds, computedElapsedSeconds]);

  return {
    elapsedTime: formatHMS(computedElapsedSeconds),
    pauseTime: formatHMS(computedPauseSeconds),
    remainingTime: formatHMS(computedRemainingSeconds),
    overtimeTime: formatHMS(computedOvertimeSeconds),
    hasOvertime: computedOvertimeSeconds > 0,
    isRunning: running && !isPaused,
  };
};

import { useEffect, useState } from "react";
import { getOperatorJobsByGroupId } from "../../../services/operatorApi";
import { getIdleTimeConfigs } from "../../../services/idleTimeConfigApi";
import type { JobEntry } from "../../../types/job";
import type { CutInputData, QuantityInputData } from "../types/cutInput";
import { createEmptyQuantityInputData } from "../types/cutInput";
import { calculateMachineHrs } from "../utils/machineHrsCalculation";
import { loadOperatorInputsFromLocalStorage, saveOperatorInputsToLocalStorage } from "../utils/operatorViewStorage";

export const useOperatorViewData = (groupId: string | null, cutIdParam: string | null) => {
  const [jobs, setJobs] = useState<JobEntry[]>([]);
  const [loadingJobs, setLoadingJobs] = useState(true);
  const [idleTimeConfigs, setIdleTimeConfigs] = useState<Map<string, number>>(new Map());
  const [cutInputs, setCutInputs] = useState<Map<number | string, CutInputData>>(new Map());
  const [expandedCuts, setExpandedCuts] = useState<Set<number | string>>(new Set());

  const parseAssignedOperators = (rawAssignedTo: unknown): string[] => {
    if (Array.isArray(rawAssignedTo)) {
      return [...new Set(rawAssignedTo.map((value) => String(value || "").trim()).filter(Boolean))];
    }
    const normalized = String(rawAssignedTo || "").trim();
    if (!normalized || normalized === "Unassigned" || normalized === "Unassign") return [];
    return [...new Set(normalized.split(",").map((value) => value.trim()).filter(Boolean))];
  };

  // Fetch idle time configs
  useEffect(() => {
    const fetchIdleTimeConfigs = async () => {
      try {
        const configs = await getIdleTimeConfigs();
        const configMap = new Map<string, number>();
        configs.forEach((config) => {
          configMap.set(config.idleTimeType, config.durationMinutes);
        });
        setIdleTimeConfigs(configMap);
      } catch (error) {
        console.error("Failed to fetch idle time configs", error);
        // Set default for Vertical Dial if fetch fails
        const defaultMap = new Map<string, number>();
        defaultMap.set("Vertical Dial", 20);
        setIdleTimeConfigs(defaultMap);
      }
    };
    fetchIdleTimeConfigs();
  }, []);

  // Fetch jobs and initialize inputs
  useEffect(() => {
    const fetchJobs = async () => {
      if (!groupId) {
        setLoadingJobs(false);
        return;
      }
      try {
        setLoadingJobs(true);
        const fetchedJobs = await getOperatorJobsByGroupId(groupId);
        
        // Filter to specific cut if cutId is provided
        let filteredJobs = fetchedJobs;
        if (cutIdParam) {
          filteredJobs = fetchedJobs.filter((job) => String(job.id) === String(cutIdParam));
        }
        
        // Try to load from localStorage first
        const savedInputs = loadOperatorInputsFromLocalStorage(groupId);
        
        // Initialize inputs for all cuts
        const initialInputs = new Map<number | string, CutInputData>();
        filteredJobs.forEach((job) => {
          const jobId = job.id;
          const existing = job as any;
          const getOpsNameArray = (rawOpsName: string | string[]) => {
            if (Array.isArray(rawOpsName)) return rawOpsName.map((value) => String(value || "").trim()).filter(Boolean);
            return rawOpsName && rawOpsName !== "Unassigned" && rawOpsName !== "Unassign"
              ? rawOpsName.split(",").map((value) => value.trim()).filter(Boolean)
              : [];
          };
          const assignedToArray = parseAssignedOperators(existing.assignedTo || "");
          
          // If we have saved data for this cut, use it
          if (savedInputs && savedInputs.has(jobId)) {
            const saved = savedInputs.get(jobId)!;
            initialInputs.set(jobId, {
              quantities: (saved.quantities || []).map((qty) => ({
                ...qty,
                machineNumber: String(existing.machineNumber || qty.machineNumber || "").trim(),
                opsName: assignedToArray.length > 0 ? assignedToArray : (Array.isArray(qty.opsName) ? qty.opsName : []),
              })),
            });
            return;
          }
          
          // Otherwise, initialize from job data
          const quantity = Math.max(1, Number(job.qty || 1));

          const quantities: QuantityInputData[] = Array.from({ length: quantity }, () => createEmptyQuantityInputData());
          const captures = Array.isArray(existing.operatorCaptures) ? existing.operatorCaptures : [];

          if (captures.length > 0) {
            captures.forEach((capture: any) => {
              const fromQty = Math.max(1, Number(capture.fromQty || 1));
              const toQty = Math.min(quantity, Math.max(fromQty, Number(capture.toQty || fromQty)));
              const captureOps = getOpsNameArray(capture.opsName || "");
              const opsNameArray = assignedToArray.length > 0 ? assignedToArray : captureOps;
              const startTime = capture.startTime || "";
              const endTime = capture.endTime || "";
              let idleTime = capture.idleTime || "";
              let idleTimeDuration = capture.idleTimeDuration || "";

              if (idleTime === "Vertical Dial") {
                if (idleTimeConfigs.has("Vertical Dial")) {
                  const durationMinutes = idleTimeConfigs.get("Vertical Dial") || 20;
                  const hours = Math.floor(durationMinutes / 60);
                  const minutes = durationMinutes % 60;
                  idleTimeDuration = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`;
                } else {
                  idleTimeDuration = "00:20";
                }
              }

              let machineHrs = capture.machineHrs || "";
              if (startTime && endTime) {
                machineHrs = calculateMachineHrs(startTime, endTime, idleTimeDuration);
              } else {
                machineHrs = "0.000";
              }

              for (let idx = fromQty - 1; idx <= toQty - 1; idx += 1) {
                quantities[idx] = {
                  startTime,
                  startTimeEpochMs: null,
                  endTime,
                  endTimeEpochMs: null,
                  machineHrs,
                  machineNumber: capture.machineNumber || "",
                  opsName: opsNameArray,
                  idleTime,
                  idleTimeDuration,
                  lastImage: capture.lastImage || null,
                  lastImageFile: null,
                  isPaused: false,
                  pauseStartTime: null,
                  totalPauseTime: 0,
                  pausedElapsedTime: 0,
                  pauseSessions: [],
                  currentPauseReason: "",
                };
              }
            });
          } else {
            const opsName = existing.opsName || "";
            const baseOps = getOpsNameArray(opsName);
            const opsNameArray = assignedToArray.length > 0 ? assignedToArray : baseOps;
            const startTime = existing.startTime || "";
            const endTime = existing.endTime || "";
            let idleTime = existing.idleTime || "";
            let idleTimeDuration = existing.idleTimeDuration || "";

            if (idleTime === "Vertical Dial") {
              if (idleTimeConfigs.has("Vertical Dial")) {
                const durationMinutes = idleTimeConfigs.get("Vertical Dial") || 20;
                const hours = Math.floor(durationMinutes / 60);
                const minutes = durationMinutes % 60;
                idleTimeDuration = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`;
              } else {
                idleTimeDuration = "00:20";
              }
            }

            let machineHrs = existing.machineHrs || "";
            if (startTime && endTime) {
              machineHrs = calculateMachineHrs(startTime, endTime, idleTimeDuration);
            } else {
              machineHrs = "0.000";
            }

            quantities[0] = {
              startTime,
              startTimeEpochMs: null,
              endTime,
              endTimeEpochMs: null,
              machineHrs,
              machineNumber: existing.machineNumber || "",
              opsName: opsNameArray,
              idleTime,
              idleTimeDuration,
              lastImage: existing.lastImage || null,
              lastImageFile: null,
              isPaused: false,
              pauseStartTime: null,
              totalPauseTime: 0,
              pausedElapsedTime: 0,
              pauseSessions: [],
              currentPauseReason: "",
            };
          }
          
          initialInputs.set(jobId, {
            quantities,
          });
        });
        
        setCutInputs(initialInputs);
        setJobs(filteredJobs);
        // Expand first cut by default
        if (filteredJobs.length > 0) {
          setExpandedCuts(new Set([filteredJobs[0].id]));
        }
      } catch (error) {
        console.error("Failed to fetch jobs", error);
      } finally {
        setLoadingJobs(false);
      }
    };
    fetchJobs();
  }, [groupId, cutIdParam, idleTimeConfigs]);

  useEffect(() => {
    if (!groupId) return;

    const syncSharedFields = async () => {
      try {
        const fetchedJobs = await getOperatorJobsByGroupId(groupId);
        const filteredJobs = cutIdParam
          ? fetchedJobs.filter((job) => String(job.id) === String(cutIdParam))
          : fetchedJobs;

        setJobs(filteredJobs);
        setCutInputs((prev) => {
          if (prev.size === 0) return prev;
          const next = new Map(prev);
          filteredJobs.forEach((job) => {
            const existingCut = next.get(job.id);
            if (!existingCut) return;
            const assignedToArray = parseAssignedOperators((job as any).assignedTo || "");
            const sharedMachine = String((job as any).machineNumber || "").trim();
            next.set(job.id, {
              ...existingCut,
              quantities: (existingCut.quantities || []).map((quantity) => ({
                ...quantity,
                machineNumber: sharedMachine || quantity.machineNumber,
                opsName: assignedToArray.length > 0 ? assignedToArray : quantity.opsName,
              })),
            });
          });
          return next;
        });
      } catch {
        // Background sync should not block operator flow.
      }
    };

    const intervalId = window.setInterval(() => {
      void syncSharedFields();
    }, 8000);

    return () => {
      window.clearInterval(intervalId);
    };
  }, [groupId, cutIdParam]);
  
  // Save to localStorage whenever cutInputs changes
  useEffect(() => {
    if (groupId && cutInputs.size > 0) {
      saveOperatorInputsToLocalStorage(groupId, cutInputs);
    }
  }, [cutInputs, groupId]);

  const toggleCutExpansion = (cutId: number | string) => {
    setExpandedCuts((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(cutId)) {
        newSet.delete(cutId);
      } else {
        newSet.add(cutId);
      }
      return newSet;
    });
  };

  return {
    jobs,
    loadingJobs,
    idleTimeConfigs,
    cutInputs,
    setCutInputs,
    expandedCuts,
    setExpandedCuts,
    toggleCutExpansion,
  };
};

import { useCallback, useEffect, useMemo, useState } from "react";
import { getActiveOperatorRunLogs, getEmployeeLogs, invalidateEmployeeLogsCache } from "../../../services/employeeLogsApi";
import type { EmployeeLog } from "../../../types/employeeLog";
import type { JobEntry } from "../../../types/job";
import { getLogUserDisplayName } from "../../../utils/jobFormatting";
import { useJobSync } from "../../../hooks/useJobSync";
import { buildOperatorCompletionAlerts } from "../utils/completionAlerts";

export const useOperatorDashboardActivity = ({
  activeTab,
  operatorGridJobs,
}: {
  activeTab: "jobs" | "logs" | "logged_jobs";
  operatorGridJobs: JobEntry[];
}) => {
  const [activeOperatorRuns, setActiveOperatorRuns] = useState<EmployeeLog[]>([]);
  const [operatorHistoryLogs, setOperatorHistoryLogs] = useState<EmployeeLog[]>([]);

  const refreshActiveRuns = useCallback(async (isMounted: boolean = true) => {
    if (document.visibilityState !== "visible") return;

    try {
      invalidateEmployeeLogsCache(/employee-logs/);
      const logs = await getActiveOperatorRunLogs();
      if (!isMounted) return;
      setActiveOperatorRuns(logs.filter((log) => String(log.jobId || "").trim() && !log.endedAt));
    } catch {
      if (isMounted) setActiveOperatorRuns([]);
    }
  }, []);

  const refreshOperatorHistory = useCallback(async (isMounted: boolean = true) => {
    try {
      invalidateEmployeeLogsCache(/employee-logs/);
      const logs = await getEmployeeLogs({ role: "OPERATOR", limit: 500 });
      if (!isMounted) return;
      setOperatorHistoryLogs(logs.filter((log) => String(log.jobId || "").trim()));
    } catch {
      if (isMounted) setOperatorHistoryLogs([]);
    }
  }, []);

  useEffect(() => {
    let isMounted = true;

    void refreshOperatorHistory(isMounted);
    return () => {
      isMounted = false;
    };
  }, [refreshOperatorHistory]);

  useEffect(() => {
    let isMounted = true;

    const loadActiveRuns = async () => {
      await refreshActiveRuns(isMounted);
    };

    void loadActiveRuns();
    if (activeTab !== "jobs") {
      return () => {
        isMounted = false;
      };
    }

    const intervalId = window.setInterval(() => {
      void loadActiveRuns();
    }, 5000);

    const handleVisibilityChange = () => {
      if (document.visibilityState === "visible") {
        void loadActiveRuns();
      }
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);

    return () => {
      isMounted = false;
      window.clearInterval(intervalId);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }, [activeTab, refreshActiveRuns]);

  useJobSync(() => {
    void refreshActiveRuns(true);
    void refreshOperatorHistory(true);
  }, activeTab === "jobs" || activeTab === "logged_jobs");

  const activeRunsByJobId = useMemo(() => {
    const map = new Map<string, EmployeeLog>();
    activeOperatorRuns.forEach((log) => {
      const jobId = String(log.jobId || "").trim();
      if (!jobId) return;
      const existing = map.get(jobId);
      const nextStartedAt = new Date(String(log.startedAt || "")).getTime();
      const existingStartedAt = new Date(String(existing?.startedAt || "")).getTime();
      if (!existing || nextStartedAt >= existingStartedAt) map.set(jobId, log);
    });
    return map;
  }, [activeOperatorRuns]);

  const operatorHistoryByJobId = useMemo(() => {
    const map = new Map<string, string[]>();
    const sortedLogs = [...operatorHistoryLogs].sort((left, right) => {
      const leftTime = new Date(String(left.startedAt || left.createdAt || 0)).getTime();
      const rightTime = new Date(String(right.startedAt || right.createdAt || 0)).getTime();
      return leftTime - rightTime;
    });

    sortedLogs.forEach((log) => {
      const jobId = String(log.jobId || "").trim();
      const userName = getLogUserDisplayName(log.userName || "", log.userEmail || "", "").toUpperCase();
      if (!jobId || !userName) return;
      const existing = map.get(jobId) || [];
      if (!existing.includes(userName)) existing.push(userName);
      map.set(jobId, existing);
    });

    return map;
  }, [operatorHistoryLogs]);

  const completionAlerts = useMemo(
    () => buildOperatorCompletionAlerts(activeOperatorRuns, operatorGridJobs),
    [activeOperatorRuns, operatorGridJobs],
  );

  return {
    activeOperatorRuns,
    activeRunsByJobId,
    completionAlerts,
    operatorHistoryByJobId,
  };
};

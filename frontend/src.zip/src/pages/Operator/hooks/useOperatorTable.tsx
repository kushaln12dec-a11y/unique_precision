import { useMemo } from "react";
import type { JobEntry } from "../../../types/job";
import type { Column } from "../../../components/DataTable";
import type { OperatorTableRow } from "../types";
import {
  getOperatorMachineDropdownOptions,
} from "../utils/operatorTableHelpers";
import { buildBaseOperatorColumns } from "../utils/operatorTableColumns";

export type OperatorDisplayRow = {
  kind: "parent" | "child";
  groupId: string;
  tableRow: OperatorTableRow;
  entry: JobEntry;
  childIndex: number | null;
  hasChildren: boolean;
  isExpanded: boolean;
};

type UseOperatorTableProps = {
  canAssign: boolean;
  operatorUsers: Array<{ id: string | number; name: string }>;
  machineOptions: string[];
  currentUserName: string;
  handleAssignChange: (jobId: number | string, value: string) => void;
  handleMachineNumberChange: (groupId: string, machineNumber: string) => void;
  handleChildMachineNumberChange: (jobId: number | string, machineNumber: string) => void;
  handleViewJob: (row: OperatorTableRow) => void;
  handleViewEntry: (entry: JobEntry) => void;
  handleSubmit: (groupId: string) => void;
  handleImageInput: (groupId: string, cutId?: string | number) => void;
  handleOpenQaModal: (entries: JobEntry[]) => void;
  isAdmin: boolean;
  isImageInputDisabled: boolean;
  toggleGroup: (groupId: string) => void;
};

export const useOperatorTable = ({
  canAssign,
  operatorUsers,
  machineOptions,
  currentUserName,
  handleAssignChange,
  handleMachineNumberChange,
  handleChildMachineNumberChange,
  handleViewJob,
  handleViewEntry,
  handleSubmit,
  handleImageInput,
  handleOpenQaModal,
  isAdmin,
  isImageInputDisabled,
  toggleGroup,
}: UseOperatorTableProps): Column<OperatorDisplayRow>[] => {
  const machineDropdownOptions = useMemo(() => getOperatorMachineDropdownOptions(machineOptions), [machineOptions]);

  const operatorNameLookup = useMemo(() => {
    const lookup = new Map<string, string>();
    operatorUsers.forEach((user) => {
      const fullName = String(user.name || "").trim();
      if (!fullName) return;
      lookup.set(fullName.toLowerCase(), fullName);
      const firstToken = fullName.split(/\s+/).filter(Boolean)[0];
      if (firstToken) {
        lookup.set(firstToken.toLowerCase(), fullName);
      }
    });
    return lookup;
  }, [operatorUsers]);

  return useMemo<Column<OperatorDisplayRow>[]>(
    () => buildBaseOperatorColumns({
      toggleGroup,
      operatorNameLookup,
      canAssign,
      operatorUsers,
      handleAssignChange,
      currentUserName,
      machineDropdownOptions,
      handleMachineNumberChange,
      handleChildMachineNumberChange,
      isAdmin,
      handleViewJob,
      handleViewEntry,
      handleSubmit,
      handleImageInput,
      handleOpenQaModal,
      isImageInputDisabled,
    }),
    [
      canAssign,
      operatorUsers,
      machineDropdownOptions,
      currentUserName,
      handleAssignChange,
      handleMachineNumberChange,
      handleChildMachineNumberChange,
      handleViewJob,
      handleViewEntry,
      handleSubmit,
      handleImageInput,
      handleOpenQaModal,
      isAdmin,
      isImageInputDisabled,
      operatorNameLookup,
      toggleGroup,
    ]
  );
};

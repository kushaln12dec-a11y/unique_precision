import type { QuantityInputData } from "../types/cutInput";
import { parseOperatorInputStartTime } from "./operatorInputState";

const resolvePauseOperatorName = (qtyData: QuantityInputData, fallbackName?: string) => {
  const explicitName = String(fallbackName || "").trim();
  if (explicitName) return explicitName.toUpperCase();
  const firstOpsName = Array.isArray(qtyData.opsName) ? String(qtyData.opsName[0] || "").trim() : "";
  return firstOpsName ? firstOpsName.toUpperCase() : "";
};

export const resumePausedQuantity = (qtyData: QuantityInputData, now: number, operatorName?: string): QuantityInputData => {
  if (!qtyData.pauseStartTime) {
    return {
      ...qtyData,
      isPaused: false,
      pauseStartTime: null,
      currentPauseOperatorName: "",
      currentPauseReason: "",
    };
  }
  const pauseDuration = qtyData.pauseStartTime ? Math.floor((now - qtyData.pauseStartTime) / 1000) : 0;
  return {
    ...qtyData,
    isPaused: false,
    pauseStartTime: null,
    totalPauseTime: qtyData.totalPauseTime + pauseDuration,
    pauseSessions: [
      ...(qtyData.pauseSessions || []),
      {
        pauseStartTime: qtyData.pauseStartTime,
        pauseEndTime: now,
        pauseDuration,
        reason: qtyData.currentPauseReason || "",
        operatorName: resolvePauseOperatorName(qtyData, qtyData.currentPauseOperatorName || operatorName),
      },
    ],
    currentPauseOperatorName: "",
    currentPauseReason: "",
  };
};

export const pauseRunningQuantity = (qtyData: QuantityInputData, now: number, operatorName?: string): QuantityInputData => {
  const startTimestamp = qtyData.startTimeEpochMs || parseOperatorInputStartTime(qtyData.startTime);
  let currentElapsed = qtyData.pausedElapsedTime;
  if (startTimestamp) {
    const segmentPauseSeconds = Math.max(0, (qtyData.totalPauseTime || 0) - (qtyData.pauseTimeOffsetSeconds || 0));
    const elapsedMs = now - startTimestamp - segmentPauseSeconds * 1000;
    currentElapsed = Math.max(0, qtyData.workedDurationSeconds + Math.floor(elapsedMs / 1000));
  }
  return {
    ...qtyData,
    isPaused: true,
    pauseStartTime: now,
    currentPauseOperatorName: resolvePauseOperatorName(qtyData, operatorName),
    pausedElapsedTime: currentElapsed,
    currentPauseReason: "",
  };
};

export const closePauseOnEndTime = (qtyData: QuantityInputData, now: number, operatorName?: string): QuantityInputData => {
  if (!qtyData.pauseStartTime) {
    return {
      ...qtyData,
      isPaused: false,
      pauseStartTime: null,
      currentPauseOperatorName: "",
      currentPauseReason: "",
    };
  }
  const pauseDuration = qtyData.pauseStartTime ? Math.max(0, Math.floor((now - qtyData.pauseStartTime) / 1000)) : 0;
  return {
    ...qtyData,
    isPaused: false,
    pauseStartTime: null,
    totalPauseTime: (qtyData.totalPauseTime || 0) + pauseDuration,
    pauseSessions: [
      ...(qtyData.pauseSessions || []),
      {
        pauseStartTime: qtyData.pauseStartTime,
        pauseEndTime: now,
        pauseDuration,
        reason: (qtyData.currentPauseReason || "").trim() || "Ended while idle",
        operatorName: resolvePauseOperatorName(qtyData, qtyData.currentPauseOperatorName || operatorName),
      },
    ],
    currentPauseOperatorName: "",
    currentPauseReason: "",
  };
};

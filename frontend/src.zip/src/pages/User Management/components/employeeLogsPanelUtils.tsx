import type { Column } from "../../../components/DataTable";
import JobRefLink from "../../../components/JobRefLink";
import MarqueeCopyText from "../../../components/MarqueeCopyText";
import type { EmployeeLog } from "../../../types/employeeLog";
import { getDisplayDateTimeParts } from "../../../utils/date";
import { formatJobRefDisplay } from "../../../utils/jobFormatting";

export type RoleTab = "PROGRAMMER" | "OPERATOR" | "QC";

export const formatRoleLabel = (role?: string) => {
  const value = String(role || "").toUpperCase();
  if (value === "PROGRAMMER") return "Programmer";
  if (value === "OPERATOR") return "Operator";
  if (value === "QC") return "QC";
  if (value === "ADMIN") return "Admin";
  return value || "-";
};

export const formatRoleShortLabel = (role?: string) => {
  const value = String(role || "").toUpperCase();
  if (value === "PROGRAMMER") return "PROG";
  if (value === "OPERATOR") return "OPS";
  if (value === "QC") return "QC";
  if (value === "ADMIN") return "ADMIN";
  return value || "-";
};

export const formatDuration = (seconds?: number) => {
  const safe = Math.max(0, Number(seconds || 0));
  const hrs = Math.floor(safe / 3600);
  const mins = Math.floor((safe % 3600) / 60);
  const secs = safe % 60;
  if (hrs > 0) return `${hrs}h ${mins}m ${secs}s`;
  if (mins > 0) return `${mins}m ${secs}s`;
  return `${secs}s`;
};

export const formatLogStatus = (status?: string) => {
  const value = String(status || "").toUpperCase();
  if (value === "IN_PROGRESS") return "RUNNING";
  if (value === "REJECTED") return "HOLD";
  if (value === "COMPLETED") return "LOGGED";
  return value || "-";
};

export const normalizeJobReference = (value?: string | number) => {
  const raw = String(value || "").trim();
  if (!raw) return "-";
  const withoutPrefix = raw.replace(/^Job\s*#?\s*/i, "").trim();
  if (!withoutPrefix) return "-";
  return formatJobRefDisplay(withoutPrefix) || "-";
};

export const formatWorkItemTitle = (value?: string) => {
  return normalizeJobReference(value);
};

export const getInitials = (value: string) => {
  const full = String(value || "").trim();
  if (!full) return "--";
  const parts = full.split(/\s+/).filter(Boolean);
  if (parts.length >= 2) return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
  return full.slice(0, 2).toUpperCase();
};

export const getWorkedSecondsForLog = (log: EmployeeLog) => {
  const metadata = (log.metadata || {}) as Record<string, any>;
  const explicitWorkedSeconds = Number(metadata.workedSeconds || 0);
  if (Number.isFinite(explicitWorkedSeconds) && explicitWorkedSeconds > 0) {
    return Math.max(0, Math.round(explicitWorkedSeconds));
  }

  const rawMachineHrs = String(metadata.machineHrs || "").trim();
  if (rawMachineHrs) {
    const hmsMatch = rawMachineHrs.match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?$/);
    if (hmsMatch) {
      const hours = Number(hmsMatch[1] || 0);
      const minutes = Number(hmsMatch[2] || 0);
      const seconds = Number(hmsMatch[3] || 0);
      if (Number.isFinite(hours) && Number.isFinite(minutes) && Number.isFinite(seconds)) {
        return Math.max(0, (hours * 3600) + (minutes * 60) + seconds);
      }
    }

    const decimalHours = Number(rawMachineHrs);
    if (Number.isFinite(decimalHours) && decimalHours > 0) {
      return Math.max(0, Math.round(decimalHours * 3600));
    }
  }

  return Math.max(0, Number(log.durationSeconds || 0));
};

export const getRevenueLabelForLog = (log: EmployeeLog) => {
  if (String(log.status || "").trim().toUpperCase() === "IN_PROGRESS") {
    return "-";
  }

  const metadata = (log.metadata || {}) as Record<string, any>;
  const explicitRevenue = metadata.revenue ?? log.revenue;
  if (explicitRevenue !== undefined && explicitRevenue !== null && String(explicitRevenue).trim() !== "") {
    const numeric = Number(explicitRevenue);
    return Number.isFinite(numeric) ? `Rs. ${numeric.toFixed(2)}` : String(explicitRevenue);
  }

  const splitRevenue = Object.values((metadata.revenueByQuantity || {}) as Record<string, unknown>).reduce<number>(
    (sum, value) => {
      const numeric = Number(value || 0);
      return Number.isFinite(numeric) ? sum + numeric : sum;
    },
    0
  );
  if (splitRevenue > 0) {
    return `Rs. ${splitRevenue.toFixed(2)}`;
  }

  return "-";
};

export const getQuantityLabel = (row: EmployeeLog) =>
  Number(row.quantityCount || 0) ||
  Number((row.metadata as any)?.quantityCount || 0) ||
  (Number(row.quantityTo || 0) && Number(row.quantityFrom || 0) ? Number(row.quantityTo) - Number(row.quantityFrom) + 1 : 0);

const formatIdleWindowRange = (startedAt: unknown, endedAt: unknown) => {
  const startedParts = getDisplayDateTimeParts(startedAt as any);
  const endedParts = endedAt ? getDisplayDateTimeParts(endedAt as any) : { date: "Open", time: "" };
  const startedLabel = `${startedParts.date} ${startedParts.time}`.trim();
  if (!startedLabel || startedLabel === "-") return "-";
  const endedLabel = endedAt ? `${endedParts.date} ${endedParts.time}`.trim() : "Open";
  return `${startedLabel} -> ${endedLabel || "Open"}`;
};

export const formatEmployeeIdleWindow = (row: EmployeeLog) => {
  const metadata = ((row.metadata as any) || {}) as Record<string, any>;
  const pauseSessions = Array.isArray(metadata.pauseSessions) ? metadata.pauseSessions : [];

  if (pauseSessions.length > 0) {
    return pauseSessions
      .map((session: any) => {
        const reason = String(session?.reason || metadata.idleTime || "Idle").trim();
        const range = formatIdleWindowRange(session?.pauseStartTime, session?.pauseEndTime);
        const duration = formatDuration(Number(session?.pauseDuration || 0));
        return `${reason}: ${range} (${duration})`;
      })
      .join(" | ");
  }

  if (metadata.idleStartedAt) {
    const reason = String(metadata.idleTime || "Idle").trim();
    const range = formatIdleWindowRange(metadata.idleStartedAt, metadata.idleEndedAt);
    const duration = metadata.idleEndedAt ? formatDuration(Number(metadata.idleDurationSeconds || 0)) : "Open";
    return `${reason}: ${range} (${duration})`;
  }

  return "-";
};

export const createEmployeeLogColumns = ({
  activeRole,
  isAdmin,
  getRevenueLabel,
}: {
  activeRole: RoleTab;
  isAdmin: boolean;
  getRevenueLabel: (row: EmployeeLog) => string;
}): Column<EmployeeLog>[] => {
  const employeeColumn: Column<EmployeeLog> = {
    key: "employee",
    label: "Employee",
    sortable: false,
    render: (row) => (
      <div className="employee-log-user employee-log-user-badge employee-log-user-inline">
        <span className="employee-log-user-initial-badge" title={String(row.userName || "Unknown User").toUpperCase()}>
          {getInitials(String(row.userName || "Unknown User"))}
        </span>
        <span className="employee-log-role-pill">{formatRoleShortLabel((row.metadata as any)?.userRole || row.role)}</span>
      </div>
    ),
  };

  if (activeRole === "OPERATOR") {
    return [
      employeeColumn,
      {
        key: "workItemTitle",
        label: "Job Ref",
        sortable: false,
        className: "employee-work-item-cell",
        render: (row) => (
          <div className="employee-work-item">
            <JobRefLink
              role={row.role}
              jobGroupId={row.jobGroupId}
              jobId={row.jobId}
              refNumber={row.refNumber}
              fallbackLabel={normalizeJobReference(row.refNumber || row.workItemTitle)}
              className="employee-job-ref-copy"
            />
          </div>
        ),
      },
      { key: "jobDescription", label: "Description", sortable: false, render: (row) => <MarqueeCopyText text={String(row.jobDescription || "-")} /> },
      { key: "workSummary", label: "Summary", sortable: false, render: (row) => <MarqueeCopyText text={String(row.workSummary || "-")} /> },
      { key: "idleTime", label: "Idle Time", sortable: false, render: (row) => String((row.metadata as any)?.idleTime || "-") },
      { key: "idleWindow", label: "Idle Window", sortable: false, render: (row) => <MarqueeCopyText text={formatEmployeeIdleWindow(row)} /> },
      { key: "remark", label: "Remark", sortable: false, render: (row) => String((row.metadata as any)?.remark || "-") },
      ...(isAdmin ? [{ key: "revenue", label: "Revenue", sortable: false, render: (row) => getRevenueLabel(row) } as Column<EmployeeLog>] : []),
      createDateColumn("startedAt", "Started At"),
      createDateColumn("endedAt", "Ended At", true),
      { key: "durationSeconds", label: "Time Taken", sortable: false, render: (row) => formatDuration(getWorkedSecondsForLog(row)) },
      createStatusColumn(),
    ];
  }

  return [
    employeeColumn,
    {
      key: "workItemTitle",
      label: "Job Ref",
      sortable: false,
      className: "employee-work-item-cell",
      render: (row) => (
        <div className="employee-work-item">
          <JobRefLink
            role={row.role}
            jobGroupId={row.jobGroupId}
            jobId={row.jobId}
            refNumber={row.refNumber}
            fallbackLabel={normalizeJobReference(row.refNumber)}
            className="employee-job-ref-copy"
          />
        </div>
      ),
    },
    { key: "jobDescription", label: "Description", sortable: false, render: (row) => <MarqueeCopyText text={String(row.jobDescription || "-")} /> },
    { key: "quantityCount", label: "Quantities", sortable: false, render: (row) => getQuantityLabel(row) || "-" },
    createDateColumn("startedAt", "Started At"),
    createDateColumn("endedAt", "Ended At", true),
    { key: "durationSeconds", label: "Time Taken", sortable: false, render: (row) => formatDuration(row.durationSeconds) },
    createStatusColumn(),
  ];
};

const createDateColumn = (key: "startedAt" | "endedAt", label: string, allowNull = false): Column<EmployeeLog> => ({
  key,
  label,
  sortable: false,
  render: (row) => {
    const parts = getDisplayDateTimeParts(allowNull ? row[key] || null : row[key]);
    return <div className="created-at-split"><span>{parts.date}</span><span>{parts.time}</span></div>;
  },
});

const createStatusColumn = (): Column<EmployeeLog> => ({
  key: "status",
  label: "Status",
  sortable: false,
  className: "employee-status-cell",
  headerClassName: "employee-status-col",
  render: (row) => <span className={`employee-log-status status-${row.status.toLowerCase()}`}>{row.status === "IN_PROGRESS" ? "RUNNING" : row.status === "REJECTED" ? "HOLD" : "LOGGED"}</span>,
});
